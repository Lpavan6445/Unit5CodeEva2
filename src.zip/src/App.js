import {Form} from './components/form';
import './App.css';

function App() {
  return (
    <div >
       <Form />
    </div>
  );
}

export default App;
